/**
 * 
 */
/**
 * @author gauta
 *
 */
module EmailApp {
}