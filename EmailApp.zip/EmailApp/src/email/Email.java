package email;

import java.util.Scanner;

public class Email {
	private String firstname;
	private String lastname;
	private String password;
	private String department;
	private String email;
	private int mailboxcapacity=500;
	private int DefaultPasswordLength=8;
	private String alternatemail;
	private String companySuffix="qstcompany.com";
	//constructor to receive fname and lname
	public Email(String firstname, String lastname) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		
		//asking for the department- return department
		this.department=setDepartment();
		
		
		//call a method that return random password
		this.password=this.setPassword(DefaultPasswordLength);
		System.out.println("Your password is:  "+this.password);
		
		//combine elements to generate email
		email=firstname.toLowerCase()+"."+lastname.toLowerCase()+"@"+department+"."+companySuffix;
		
	}
	//ask for the department
	private String setDepartment() {
		System.out.println("New worker: "+firstname+" Welcome to our company \nEnter the department code: \n1.For sales \n2.for department \n3.for accounting \n0.None \nEnter:");
		Scanner sc=new Scanner(System.in);
		int depchoice=sc.nextInt();
		if(depchoice==1) {return "sales";}
		else if(depchoice==2){return "dept";}
		else if(depchoice==3){return "acct";}
		else {return "";}
		
	}
	//Generate a random password
	private String setPassword(int len) {
		String passwordSet="ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789!@#$%";
		char[] password=new char[len];
		for(int i=0;i<len;i++) {
			int rand=(int) (Math.random()*passwordSet.length());
			password[i]=passwordSet.charAt(rand);
		}
		return new String(password);
	}
	//set the mailbox capacity
	public void setMailboxcapacity(int capacity) {
		this.mailboxcapacity=capacity;
	}
	//set alternate email
	public void setAlternateemail(String altEmail) {
		this.alternatemail=altEmail;
	}
	//to change the password
	public void setChangePassword(String password) {
		this.password=password;
		
	}
	public int getmailboxcapacity() {return mailboxcapacity;}
	public String getalternatemail() {return alternatemail;}
	public String getpassword() {return password;}
	
	public String ShowInfo() {
		return "Employee name: "+firstname+" "+lastname+
				"\nCompany Email: "+email+
				"\nMailBoxCapacity: "+mailboxcapacity+"mb";
				
	}
	
}
