package email;

public class EmailApp {
	public static void main(String[] args) {
		Email e=new Email("Riya", "sen");
		String r=e.ShowInfo();
		System.out.println(r);
		
	}
}
